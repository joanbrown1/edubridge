import React, { useState } from 'react';
import { ThemeProvider } from './components/ThemeProvider';
import { AnimatedBackground } from './components/AnimatedBackground';
import { Navigation } from './components/Navigation';
import { LandingPage } from './components/LandingPage';
import { InputPage } from './components/InputPage';
import { ResultsPage } from './components/ResultsPage';
import { DemoPage } from './components/DemoPage';
import { AboutPage } from './components/AboutPage';
import { HistoryPage } from './components/HistoryPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState('landing');

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'landing':
        return <LandingPage onNavigate={handleNavigate} />;
      case 'input':
        return <InputPage onNavigate={handleNavigate} />;
      case 'results':
        return <ResultsPage onNavigate={handleNavigate} />;
      case 'history':
        return <HistoryPage onNavigate={handleNavigate} />;
      case 'demo':
        return <DemoPage onNavigate={handleNavigate} />;
      case 'about':
        return <AboutPage onNavigate={handleNavigate} />;
      default:
        return <LandingPage onNavigate={handleNavigate} />;
    }
  };

  return (
    <ThemeProvider>
      <div className="min-h-screen bg-background text-foreground overflow-x-hidden relative transition-colors duration-300">
      {/* Animated Background */}
      <AnimatedBackground />
      
      {/* Navigation */}
      <Navigation currentPage={currentPage} onNavigate={handleNavigate} />
      
      {/* Main Content */}
      <main className="relative z-10 pt-16">
        {renderPage()}
      </main>
      
      {/* Global styles for special effects */}
      <style jsx global>{`
        .preserve-3d {
          transform-style: preserve-3d;
        }
        
        .backface-hidden {
          backface-visibility: hidden;
        }
        
        .rotate-y-180 {
          transform: rotateY(180deg);
        }
        
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-20px); }
        }
        
        .animate-float {
          animation: float 3s ease-in-out infinite;
        }
        
        /* Glassmorphism effects */
        .glass-effect {
          backdrop-filter: blur(10px);
        }
        
        :root .glass-effect {
          background: rgba(255, 255, 255, 0.1);
          border: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .dark .glass-effect {
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        /* Custom scrollbar */
        ::-webkit-scrollbar {
          width: 8px;
        }
        
        :root ::-webkit-scrollbar-track {
          background: rgba(0, 0, 0, 0.1);
        }
        
        .dark ::-webkit-scrollbar-track {
          background: rgba(30, 41, 59, 0.5);
        }
        
        ::-webkit-scrollbar-thumb {
          background: rgba(59, 130, 246, 0.5);
          border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: rgba(59, 130, 246, 0.7);
        }
        
        /* Smooth transitions for all interactive elements */
        button, input, textarea, select {
          transition: all 0.3s ease;
        }
        
        /* Enhance focus visibility */
        button:focus-visible,
        input:focus-visible,
        textarea:focus-visible {
          outline: 2px solid #3B82F6;
          outline-offset: 2px;
        }
        
        /* Typography enhancements */
        h1, h2, h3, h4 {
          text-rendering: optimizeLegibility;
        }
        
        /* Ensure proper text contrast */
        .text-gradient {
          background: linear-gradient(135deg, #3B82F6, #9333EA, #06B6D4);
          -webkit-background-clip: text;
          background-clip: text;
          -webkit-text-fill-color: transparent;
        }
      `}</style>
      </div>
    </ThemeProvider>
  );
}