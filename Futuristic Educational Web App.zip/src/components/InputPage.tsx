import React, { useState } from 'react';
import { motion } from 'motion/react';
import { GlowingButton } from './GlowingButton';
import { GlassCard } from './GlassCard';
import { Upload, FileText, Zap } from 'lucide-react';

interface InputPageProps {
  onNavigate: (page: string) => void;
}

export function InputPage({ onNavigate }: InputPageProps) {
  const [content, setContent] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerate = () => {
    if (!content.trim()) return;
    
    setIsLoading(true);
    // Simulate processing time
    setTimeout(() => {
      setIsLoading(false);
      onNavigate('results');
    }, 3000);
  };

  const handleDemo = () => {
    onNavigate('demo');
  };

  return (
    <div className="min-h-screen text-foreground flex flex-col items-center justify-center px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="w-full max-w-4xl"
      >
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            Transform Your Content
          </h1>
          <p className="text-muted-foreground text-lg">
            Paste your notes or upload a document to get started
          </p>
        </div>

        <GlassCard className="mb-8">
          <div className="space-y-6">
            {/* Text Input Area */}
            <div className="relative">
              <label className="block text-blue-600 dark:text-blue-300 font-medium mb-3">
                Your Content
              </label>
              <div className="relative">
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Paste your notes here..."
                  rows={12}
                  className="w-full bg-secondary/30 backdrop-blur-sm border border-border rounded-lg p-4 text-foreground placeholder-muted-foreground focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 focus:outline-none transition-all duration-300 resize-none"
                  style={{
                    background: 'linear-gradient(135deg, rgba(30, 41, 59, 0.5) 0%, rgba(15, 23, 42, 0.5) 100%)',
                  }}
                />
                {/* Typing cursor animation */}
                {content === '' && (
                  <div className="absolute top-4 left-4 w-0.5 h-6 bg-blue-500 animate-pulse" />
                )}
                
                {/* Glowing border on focus */}
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-cyan-500/20 opacity-0 focus-within:opacity-100 transition-opacity duration-300 rounded-lg pointer-events-none" />
              </div>
            </div>

            {/* Upload Section */}
            <div className="border-t border-slate-600/30 pt-6">
              <label className="block text-purple-600 dark:text-purple-300 font-medium mb-3">
                Or Upload a Document
              </label>
              <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-purple-500/50 transition-colors duration-300 group">
                <Upload className="w-12 h-12 text-muted-foreground mx-auto mb-4 group-hover:text-purple-500 transition-colors duration-300" />
                <p className="text-foreground mb-2">Drag & drop your files here</p>
                <p className="text-muted-foreground text-sm mb-4">Supports PDF, DOC, DOCX files</p>
                <GlowingButton variant="secondary" size="sm">
                  <FileText className="w-4 h-4 mr-2" />
                  Browse Files
                </GlowingButton>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-6">
              <GlowingButton 
                onClick={handleGenerate}
                disabled={!content.trim() || isLoading}
                className="flex-1"
                size="lg"
              >
                {isLoading ? (
                  <div className="flex items-center justify-center">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                    Processing...
                  </div>
                ) : (
                  <>
                    <Zap className="w-5 h-5 mr-2" />
                    Generate Outputs
                  </>
                )}
              </GlowingButton>
              
              <GlowingButton 
                variant="secondary" 
                onClick={handleDemo}
                size="lg"
                className="sm:w-auto"
              >
                Try Demo
              </GlowingButton>
            </div>
          </div>
        </GlassCard>

        {/* Loading Animation */}
        {isLoading && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center"
          >
            <GlassCard>
              <div className="py-8">
                <div className="flex justify-center mb-6">
                  <div className="relative">
                    {/* Circuit-style progress animation */}
                    <div className="w-24 h-24 border-4 border-slate-600/30 rounded-full relative">
                      <div className="absolute inset-0 border-4 border-transparent border-t-blue-500 border-r-purple-500 rounded-full animate-spin" />
                      <div className="absolute inset-2 border-2 border-transparent border-t-cyan-400 rounded-full animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }} />
                    </div>
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-blue-300 mb-2">
                  AI Processing Your Content
                </h3>
                <p className="text-slate-400">
                  Generating summaries, quizzes, and flashcards...
                </p>
                
                {/* Progress indicators */}
                <div className="mt-6 space-y-3">
                  {['Analyzing content structure...', 'Extracting key concepts...', 'Creating learning materials...'].map((step, index) => (
                    <motion.div
                      key={step}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.8, duration: 0.5 }}
                      className="flex items-center text-sm text-slate-300"
                    >
                      <div className="w-2 h-2 bg-blue-400 rounded-full mr-3 animate-pulse" />
                      {step}
                    </motion.div>
                  ))}
                </div>
              </div>
            </GlassCard>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}