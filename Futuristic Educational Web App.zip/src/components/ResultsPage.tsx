import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GlowingButton } from './GlowingButton';
import { GlassCard } from './GlassCard';
import { FileText, HelpCircle, Layers, Volume2, Download, RotateCcw, CheckCircle } from 'lucide-react';

interface ResultsPageProps {
  onNavigate: (page: string) => void;
}

const flashcards = [
  { front: "What is Machine Learning?", back: "A subset of AI that enables computers to learn and improve from experience without being explicitly programmed." },
  { front: "What is Deep Learning?", back: "A subset of machine learning based on artificial neural networks with multiple layers." },
  { front: "What is Neural Network?", back: "A computing system inspired by biological neural networks that learn to perform tasks by considering examples." }
];

const quizQuestions = [
  {
    question: "Which of the following best describes machine learning?",
    options: [
      "A programming language for AI",
      "A method for computers to learn from data",
      "A type of computer hardware",
      "A database management system"
    ],
    correct: 1
  },
  {
    question: "What is the main advantage of deep learning?",
    options: [
      "It requires less data",
      "It's faster than traditional algorithms",
      "It can automatically discover patterns in complex data",
      "It uses less computational power"
    ],
    correct: 2
  }
];

export function ResultsPage({ onNavigate }: ResultsPageProps) {
  const [activeTab, setActiveTab] = useState('summary');
  const [currentCard, setCurrentCard] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);

  const tabs = [
    { id: 'summary', label: 'Summary', icon: FileText },
    { id: 'quiz', label: 'Quiz', icon: HelpCircle },
    { id: 'flashcards', label: 'Flashcards', icon: Layers }
  ];

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
    setShowResult(true);
    setTimeout(() => {
      if (currentQuestion < quizQuestions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedAnswer(null);
        setShowResult(false);
      }
    }, 2000);
  };

  const nextCard = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentCard((prev) => (prev + 1) % flashcards.length);
    }, 150);
  };

  const prevCard = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentCard((prev) => (prev - 1 + flashcards.length) % flashcards.length);
    }, 150);
  };

  return (
    <div className="min-h-screen text-white px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="max-w-6xl mx-auto"
      >
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            Your Learning Materials
          </h1>
          <div className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-full border border-green-500/30">
            <CheckCircle className="w-5 h-5 text-green-400 mr-2" />
            <span className="text-green-300 font-medium">AI generated this in seconds</span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-8">
          <div className="flex bg-slate-800/50 backdrop-blur-sm rounded-lg border border-slate-600/50 p-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`
                    relative flex items-center px-6 py-3 rounded-lg transition-all duration-300 font-medium
                    ${activeTab === tab.id 
                      ? 'text-white bg-gradient-to-r from-blue-600 to-purple-600 shadow-lg shadow-blue-500/25' 
                      : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                    }
                  `}
                >
                  <Icon className="w-5 h-5 mr-2" />
                  {tab.label}
                  {activeTab === tab.id && (
                    <motion.div
                      layoutId="activeTab"
                      className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg -z-10"
                      transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Tab Content */}
        <AnimatePresence mode="wait">
          {activeTab === 'summary' && (
            <motion.div
              key="summary"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              <GlassCard>
                <div className="space-y-6">
                  <h2 className="text-2xl font-semibold text-blue-300 mb-4">
                    AI-Generated Summary
                  </h2>
                  
                  <div className="prose prose-invert max-w-none">
                    <h3 className="text-xl text-purple-300">Key Concepts</h3>
                    <ul className="text-slate-300 space-y-2">
                      <li><strong className="text-blue-300">Machine Learning:</strong> A powerful subset of artificial intelligence that enables computers to learn and improve from experience without explicit programming.</li>
                      <li><strong className="text-blue-300">Deep Learning:</strong> An advanced form of machine learning using multi-layered neural networks to process complex data patterns.</li>
                      <li><strong className="text-blue-300">Neural Networks:</strong> Computing systems inspired by biological neural networks, designed to recognize patterns and make decisions.</li>
                    </ul>
                    
                    <h3 className="text-xl text-purple-300 mt-6">Main Points</h3>
                    <p className="text-slate-300">
                      The document explores the fundamentals of artificial intelligence, focusing on machine learning techniques and their applications. 
                      It emphasizes how these technologies can transform data processing and decision-making across various industries.
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-4 pt-6 border-t border-slate-600/30">
                    <GlowingButton variant="secondary">
                      <Volume2 className="w-4 h-4 mr-2" />
                      Listen
                    </GlowingButton>
                    <GlowingButton variant="secondary">
                      <Download className="w-4 h-4 mr-2" />
                      Export
                    </GlowingButton>
                  </div>
                </div>
              </GlassCard>
            </motion.div>
          )}

          {activeTab === 'quiz' && (
            <motion.div
              key="quiz"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              <GlassCard>
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <h2 className="text-2xl font-semibold text-purple-300">
                      Interactive Quiz
                    </h2>
                    <span className="text-slate-400">
                      Question {currentQuestion + 1} of {quizQuestions.length}
                    </span>
                  </div>

                  <div className="space-y-6">
                    <h3 className="text-xl text-white font-medium">
                      {quizQuestions[currentQuestion].question}
                    </h3>

                    <div className="space-y-3">
                      {quizQuestions[currentQuestion].options.map((option, index) => (
                        <button
                          key={index}
                          onClick={() => handleAnswerSelect(index)}
                          disabled={showResult}
                          className={`
                            w-full p-4 rounded-lg border transition-all duration-300 text-left
                            ${selectedAnswer === index
                              ? index === quizQuestions[currentQuestion].correct
                                ? 'bg-green-500/20 border-green-500/50 text-green-300'
                                : 'bg-red-500/20 border-red-500/50 text-red-300'
                              : showResult && index === quizQuestions[currentQuestion].correct
                                ? 'bg-green-500/20 border-green-500/50 text-green-300'
                                : 'bg-slate-700/30 border-slate-600/50 text-slate-300 hover:bg-slate-600/30 hover:border-slate-500/50'
                            }
                            disabled:cursor-not-allowed
                          `}
                        >
                          <div className="flex items-center">
                            <span className="w-8 h-8 bg-slate-600/50 rounded-full flex items-center justify-center mr-3 text-sm">
                              {String.fromCharCode(65 + index)}
                            </span>
                            {option}
                          </div>
                        </button>
                      ))}
                    </div>

                    {showResult && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`p-4 rounded-lg ${
                          selectedAnswer === quizQuestions[currentQuestion].correct
                            ? 'bg-green-500/20 border border-green-500/50'
                            : 'bg-red-500/20 border border-red-500/50'
                        }`}
                      >
                        <p className={`font-medium ${
                          selectedAnswer === quizQuestions[currentQuestion].correct
                            ? 'text-green-300'
                            : 'text-red-300'
                        }`}>
                          {selectedAnswer === quizQuestions[currentQuestion].correct
                            ? '✓ Correct!'
                            : '✗ Incorrect'}
                        </p>
                      </motion.div>
                    )}
                  </div>
                </div>
              </GlassCard>
            </motion.div>
          )}

          {activeTab === 'flashcards' && (
            <motion.div
              key="flashcards"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              <div className="max-w-2xl mx-auto">
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-semibold text-cyan-300 mb-2">
                    Flashcards
                  </h2>
                  <p className="text-slate-400">
                    Card {currentCard + 1} of {flashcards.length}
                  </p>
                </div>

                {/* Flashcard */}
                <div className="relative h-64 mb-8">
                  <motion.div
                    animate={{ rotateY: isFlipped ? 180 : 0 }}
                    transition={{ duration: 0.6 }}
                    className="w-full h-full preserve-3d cursor-pointer"
                    onClick={() => setIsFlipped(!isFlipped)}
                    style={{ transformStyle: 'preserve-3d' }}
                  >
                    {/* Front */}
                    <div className="absolute inset-0 backface-hidden">
                      <GlassCard className="h-full" hover={false}>
                        <div className="h-full flex flex-col items-center justify-center text-center p-8">
                          <h3 className="text-xl font-semibold text-blue-300 mb-4">
                            Question
                          </h3>
                          <p className="text-lg text-white">
                            {flashcards[currentCard].front}
                          </p>
                          <p className="text-sm text-slate-400 mt-4">
                            Click to reveal answer
                          </p>
                        </div>
                      </GlassCard>
                    </div>

                    {/* Back */}
                    <div className="absolute inset-0 backface-hidden rotate-y-180">
                      <GlassCard className="h-full" hover={false}>
                        <div className="h-full flex flex-col items-center justify-center text-center p-8">
                          <h3 className="text-xl font-semibold text-purple-300 mb-4">
                            Answer
                          </h3>
                          <p className="text-lg text-white">
                            {flashcards[currentCard].back}
                          </p>
                          <p className="text-sm text-slate-400 mt-4">
                            Click to flip back
                          </p>
                        </div>
                      </GlassCard>
                    </div>
                  </motion.div>
                </div>

                {/* Navigation */}
                <div className="flex justify-center space-x-4">
                  <GlowingButton variant="secondary" onClick={prevCard}>
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Previous
                  </GlowingButton>
                  <GlowingButton onClick={() => setIsFlipped(!isFlipped)}>
                    Flip Card
                  </GlowingButton>
                  <GlowingButton variant="secondary" onClick={nextCard}>
                    Next
                    <RotateCcw className="w-4 h-4 ml-2 rotate-180" />
                  </GlowingButton>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Back to Input */}
        <div className="text-center mt-12">
          <GlowingButton variant="secondary" onClick={() => onNavigate('input')}>
            Process New Content
          </GlowingButton>
        </div>
      </motion.div>
    </div>
  );
}